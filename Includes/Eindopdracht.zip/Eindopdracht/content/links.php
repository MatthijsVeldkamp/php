<a href="index.php?page=1">Home&nbsp;</a>
<a href="index.php?page=2">Minecraft&nbsp;</a>
<a href="index.php?page=3">Commodore 64&nbsp;</a>
<a href="index.php?page=4">Schoolopdrachten&nbsp;</a>
<a href="index.php?page=5">Wat ik heb geleerd&nbsp;</a>