<h1>Wat ik heb geleerd</h1>
<h3>Ik heb geleerd dat je met een GET request de pagina kan veranderen en zo dynamisch kan maken.
<h3>Bijvoorbeeld dat de links en footer niet veranderen en dat je in de url de "?page" kan zien.</h3>