<h1>Vorige schoolopdrachten</h1>
<br>
<hr width=50%>
<br>
<h1>Python:</h1>
<br>
<hr width=50%>
<br>
<h3>Aan het begin van de opleiding heb ik met Python gewerkt.</h3>
<h3>Ik heb geleerd hoe je een programma moet maken en hoe je een programma moet runnen.</h3>
<h3>Ook heb ik geleerd hoe je het beste een programma moet debuggen.</h3>
<br>
<hr width=50%>
<br>
<h1>HTML / CSS / JavaScript:</h1>
<br>
<hr width=50%>
<br>
<h3>Ik heb geleerd hoe je een website moet maken met HTML.</h3>
<h3>Ook heb ik geleerd hoe je een website moet stylen met CSS.</h3>
<h3>Met JavaScript heb ik geleerd hoe je met scripts je website nuttig kan maken.</h3>
<br>
<hr width=50%>
<br>
<h1>PHP:</h1>
<br>
<hr width=50%>
<br>
<h3>Ik heb geleerd hoe je een website kan maken met PHP.</h3>
<h3>Met PHP heb ik geleerd hoe je een website dynamisch kan maken.</h3>
<br>
<hr width=50%>
<br>
<h1>MySQL:</h1>
<br>
<hr width=50%>
<br>
<h3>Ik heb geleerd hoe je een database kan maken met MySQL.</h3>
<h3>Ook heb ik geleerd hoe je een database kan updaten.</h3>
<br>