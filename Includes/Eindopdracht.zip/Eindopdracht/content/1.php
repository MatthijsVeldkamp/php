<img id="myimg" src="content/download.png" width=500px height=auto alt="img">
<h1>Welkom op mijn dynamische pagina!</h1>
<h2>Deze pagina is gemaakt met php, html, css en JavaScript.</h2>