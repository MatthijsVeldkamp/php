<h1>Commodore 64</h1>
<hr width="50%">
<br>
<h2>De Commodore 64, vaak afgekort als C64, is een iconische thuiscomputer die in de jaren 80</h2>
<h2>een enorme invloed had op de computerindustrie en de gamingwereld. </h2>
<br>
<h2>Mijn opa heeft (nog steeds) een C64, waar ik als kind erg veel op programmeerde.</h2>
<h2>Uren door de handleiding bladeren en programma's overtypen.</h2>
<h2>Later die programma's stuk voor stuk te veranderen om te kijken wat er gebeurde.</h2>
<h2>Uiteindelijk na genoeg ervaring kon ik ook zelf games maken.</h2>
<br>
<h2>De programma's die ik maakte sloeg ik op via floppy disks. (5 inch)</h2>
<h2>Hierdoor de reden dat ik de opleiding software developer erg leuk vind.</h2>
<br>
<img width="720" src="C64.png" alt="C64 png">
<br>
<h4>De C64 met handleiding, doos en cassette drive.</h4>
<br>
<hr width="50%">
<br>
<h1>Programeertaal</h1>
<br>
<h3>De Commodore 64 gebruikt de programmeertaal BASIC die in de jaren 60 is ontwikkeld.</h3>
<h3>Deze taal is erg makkelijk te leren en te begrijpen en het lijkt een beetje op de moderne programmeertaal Python.</h3>
<br>
<img width="720" src="C64.gif" alt="C64 gif">
<h4>Het scherm wat je ziet wanneer de computer is opgestart.</h4>
<br>
<hr width="50%">
<br>
<h1>Voorbeelden van BASIC</h1>
<br>
<h3>10 PRINT "Hello World"</h3>
<h3>20 GOTO 10</h3>
<h3>Een super simpele loop waar de hele tijd "Hello world" word gezegd.</h3>
<br>
<hr width="12%">
<br>
<h3>10 INPUT "Wat is je naam?"; A$</h3>
<h3>20 PRINT "Hallo "; A$</h3>
<h3>De naam wat de gebruiker invult word opgeslagen als A</h3>
<h3>Hierna word het geprint met de tekst "Hallo " ervoor.</h3>
<br>
<hr width="50%">
<br>
<h1>Hoe ik de taal heb geleerd.</h1>
<br>
<h3>De handleiding was een enorm hulpmiddel.</h3>
<img width="720" src="guessing_game.jpg" alt="guessing_game">
<h3>Dit soort programma's typte ik over op de C64.</h3>
<h3>Uiteindelijk begreep ik variables en hoe ik moest rekenen met de C64. Enz, enz</h3>
<h3>Door online handleidingen die vaak in het Engels stonden werd mijn Engels ook beter en beter.</h3>