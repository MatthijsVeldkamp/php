<h2>Minecraft</h2>
<h3>Minecraft, ontwikkeld door Mojang Studios, is een sandbox-avonturengame die spelers de vrijheid geeft om hun eigen werelden te bouwen en te verkennen.</h3>
<h3>Met zijn kenmerkende blokkerige grafische stijl en eindeloze mogelijkheden voor creativiteit en samenwerking, heeft Minecraft een enorme en trouwe fanbase opgebouwd.</h3>
<img src="../Eindopdracht/Stockholm2.png" width="700" alt="Stockholm1">
<br>
<img src="../Eindopdracht/Stockholm1.png" width="700" alt="Stockholm2">
<h3>Mijn bezoek aan Mojang Studios in Stockholm, Zweden</h3>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2035.7345455022648!2d18.0514994!3d59.3206895!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x465f77dd8f5bdf07%3A0xe3a8ee341cc7043!2sMojang%20Studios!5e0!3m2!1sen!2snl!4v1686033948589!5m2!1sen!2snl" width="800" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
<h3>Zelf speel ik minecraft vanaf 2012 (vanaf Minecraft Java Edition 1.1)</h3>
<h3>Het was vroeger en nu nog steeds mijn favoriete spel wat ik soms nog steeds met vrienden speel.</h3>
<br>
<h2>De muziek</h2>
<h3>De muziek in Minecraft is gecomponeerd door Daniel Rosenfeld, beter bekend als C418.</h3>
<h3>Het meest populaire nummer is Sweden.</h3>
<h3>Deze muziek is gemaakt in 2011 en is nog steeds erg populair.</h3>
<h3>C418 heeft op dit moment ruim 2,5 miljoen maandelijkse luisteraars op Spotify.</h3>
<iframe style="border-radius:12px" src="https://open.spotify.com/embed/artist/4uFZsG1vXrPcvnZ4iSQyrx?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>